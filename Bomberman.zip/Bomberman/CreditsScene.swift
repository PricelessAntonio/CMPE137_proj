//
//  CreditsScene.swift
//  Bomberman
//
//  Created by user125107 on 4/25/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class CreditsScene: SKScene {

    var returnToMenuSceneButtonNode:SKSpriteNode!
    var titleLabelNode: SKLabelNode!
    var antonioLabelNode: SKLabelNode!
    var khoaLabelNode: SKLabelNode!
    var danLabelNode: SKLabelNode!
    var luisLabelNode: SKLabelNode!
    
    override func didMove(to view: SKView) {
        returnToMenuSceneButtonNode = self.childNode(withName: "returnToMenuSceneButton") as! SKSpriteNode
        returnToMenuSceneButtonNode.texture = SKTexture(imageNamed:"returnToMenuSceneButton")
        
        titleLabelNode = self.childNode(withName: "titleLabel") as! SKLabelNode
        antonioLabelNode = self.childNode(withName: "antonioLabel") as! SKLabelNode
        khoaLabelNode = self.childNode(withName: "khoaLabel") as! SKLabelNode
        danLabelNode = self.childNode(withName: "danLabel") as! SKLabelNode
        luisLabelNode = self.childNode(withName: "luisLabel") as! SKLabelNode
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If returnToMenuSceneButton is pressed, game transitions to MenuScene
        
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
            case returnToMenuSceneButtonNode:
                playButtonSound()
                self.view?.presentScene(MenuScene(fileNamed:"MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
        }

    }

    func playButtonSound() {
        self.run(SKAction.playSoundFileNamed("button.wav", waitForCompletion: false))  //Plays the sound file
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
}



