//
//  GameScene.swift
//  Bomberman
//
//  Created by user125107 on 4/1/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameScene: SKScene {

    var gameOverButtonNode:SKSpriteNode!
    
    override func didMove(to view: SKView) {
        
        //print("gameOverButton = ")//\(gameOverButtonNode)")
        gameOverButtonNode = self.childNode(withName: "gameOverButton") as! SKSpriteNode
        gameOverButtonNode.texture = SKTexture(imageNamed: "gameOverButton")
        
        /*gameOverButtonNode = SKSpriteNode(imageNamed: "gameOverButton")
        gameOverButtonNode.position = CGPoint(x:self.frame.size.width / 2, y: self.frame.size.height / 2)
        self.addChild(gameOverButtonNode)*/
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If gameOverButton is pressed, game transitions into GameOverScene
    
    let touch = touches.first
    
    if let location = touch?.location(in: self) {
        let node = self.nodes(at: location)
        
        if node[0].name == "gameOverButton" {
            let transition = SKTransition.fade(withDuration: 1)
            let gameOverScene = GameOverScene(fileNamed: "GameOverScene")//(size: self.size)
            self.view?.presentScene(gameOverScene!, transition: transition)
            }
        }
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
}
