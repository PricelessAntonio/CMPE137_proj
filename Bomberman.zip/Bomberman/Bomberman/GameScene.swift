//
//  GameScene.swift
//  Bomberman
//
//  Created by user125107 on 4/1/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameScene: SKScene {

    var gameOverButtonNode:SKSpriteNode!
    
    override func didMove(to view: SKView) {
        
        gameOverButtonNode = self.childNode(withName: "gameOverButton") as! SKSpriteNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If gameOverButton is pressed, game transitions into GameOverScene
    
    let touch = touches.first
    
    if let location = touch?.location(in: self) {
        let node = self.nodes(at: location)
        
        if node[0].name == "gameOverButton" {
            let transition = SKTransition.fade(withDuration: 1)
            let gameOverScene = GameOverScene(size: self.size)
            self.view!.presentScene(gameOverScene, transition: transition)
            }
        }
    }
    
}
