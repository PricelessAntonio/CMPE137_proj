//
//  LeaderboardScene.swift
//  Bomberman
//
//  Created by Student on 5/15/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class LeaderboardScene: SKScene {

}
