//
//  MenuScene.swift
//  Bomberman
//
//  Created by user125107 on 4/1/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit


class MenuScene: SKScene {
    
    var singlePlayerButtonNode = SKSpriteNode()
    var creditsButtonNode = SKSpriteNode()
    var settingsButtonNode = SKSpriteNode()
    var tutorialButtonNode = SKSpriteNode()
    var titleLabelNode = SKLabelNode()
    
    override func didMove(to view: SKView) {    //Searches for the childNode name and the corresponding button
        
        singlePlayerButtonNode = self.childNode(withName: "singlePlayerButton") as! SKSpriteNode
        creditsButtonNode = self.childNode(withName: "creditsButton") as! SKSpriteNode
        settingsButtonNode = self.childNode(withName: "settingsButton") as! SKSpriteNode
        tutorialButtonNode = self.childNode(withName: "tutorialButton") as! SKSpriteNode
        titleLabelNode = self.childNode(withName: "titleLabel") as! SKLabelNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If a button is pressed, the game transitions into the button's respective scene
 
        let touch = touches.first
        
        if let location = touch?.location(in: self) {
            let node = self.nodes(at: location)
            
            if node[0].name == "singlePlayerButton" {
                let transition = SKTransition.fade(withDuration: 1)
                let gameScene = GameScene(fileNamed: "GameScene")
                self.view?.presentScene(gameScene!, transition: transition)
            }
            
            if node[0].name == "creditsButton" {
                let transition = SKTransition.fade(withDuration: 1)
                let creditsScene = CreditsScene(fileNamed: "CreditsScene")
                self.view?.presentScene(creditsScene!, transition: transition)
            }
            
            if node[0].name == "settingsButton" {
                let transition = SKTransition.fade(withDuration: 1)
                let settingsScene = SettingsScene(fileNamed: "SettingsScene")
                self.view?.presentScene(settingsScene!, transition: transition)
            }
            
            if node[0].name == "tutorialButton" {
                let transition = SKTransition.fade(withDuration: 1)
                let tutorialScene = TutorialsScene(fileNamed: "TutorialsScene")
                self.view?.presentScene(tutorialScene!, transition: transition)
            }
        }
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }

}
