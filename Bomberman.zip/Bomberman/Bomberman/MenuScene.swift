//
//  MenuScene.swift
//  Bomberman
//
//  Created by user125107 on 4/1/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit


class MenuScene: SKScene {
    
    var singlePlayerButtonNode = SKSpriteNode()
    var creditsButtonNode = SKSpriteNode()
    var settingsButtonNode = SKSpriteNode()
    var tutorialButtonNode = SKSpriteNode()
    var titleLabelNode = SKLabelNode()
    
    override func didMove(to view: SKView) {    //Searches for the childNode name and the corresponding button
        
        singlePlayerButtonNode = self.childNode(withName: "singlePlayerButton") as! SKSpriteNode
        creditsButtonNode = self.childNode(withName: "creditsButton") as! SKSpriteNode
        settingsButtonNode = self.childNode(withName: "settingsButton") as! SKSpriteNode
        tutorialButtonNode = self.childNode(withName: "tutorialButton") as! SKSpriteNode
        titleLabelNode = self.childNode(withName: "titleLabel") as! SKLabelNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If a button is pressed, the game transitions into the button's respective scene
 
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
            case singlePlayerButtonNode:
                self.view?.presentScene(GameScene(fileNamed: "GameScene")!, transition: SKTransition.fade(withDuration: 1))
            case creditsButtonNode:
                self.view?.presentScene(CreditsScene(fileNamed: "CreditsScene")!, transition: SKTransition.fade(withDuration: 1))
            case settingsButtonNode:
                self.view?.presentScene(SettingsScene(fileNamed: "SettingsScene")!, transition: SKTransition.fade(withDuration: 1))
            case tutorialButtonNode:
                self.view?.presentScene(TutorialsScene(fileNamed: "TutorialsScene")!, transition: SKTransition.fade(withDuration:1))
            default:
                break;
            }
        }
        
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }

}
