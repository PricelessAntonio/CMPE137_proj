//
//  SettingsScene.swift
//  Bomberman
//
//  Created by user125107 on 4/25/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class SettingsScene: SKScene {

    var returnToMenuSceneButtonNode:SKSpriteNode!
    var bgmOffNode: SKSpriteNode!
    var bgmOnNode: SKSpriteNode!
    var sfxOffNode: SKSpriteNode!
    var sfxOnNode: SKSpriteNode!
    var titleLabelNode: SKLabelNode!
    var bgmLabelNode: SKLabelNode!
    var sfxLabelNode: SKLabelNode!
    
    override func didMove(to view: SKView) {
        returnToMenuSceneButtonNode = self.childNode(withName: "returnToMenuSceneButton") as! SKSpriteNode
        bgmOffNode = self.childNode(withName: "bgmOff") as! SKSpriteNode
        bgmOnNode = self.childNode(withName: "bgmOn") as! SKSpriteNode
        sfxOffNode = self.childNode(withName: "sfxOff") as! SKSpriteNode
        sfxOnNode = self.childNode(withName: "sfxOn") as! SKSpriteNode
        titleLabelNode = self.childNode(withName: "titleLabel") as! SKLabelNode
        bgmLabelNode = self.childNode(withName: "bgmLabel") as! SKLabelNode
        sfxLabelNode = self.childNode(withName: "sfxLabel") as! SKLabelNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If returnToMenuSceneButton is pressed, game transitions to MenuScene
        
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
            case bgmOffNode:
                music.autoplayLooped = false
            case bgmOnNode:
                music.autoplayLooped = true
//            case sfxOffNode:
                //buttonSFX.autoplayLooped = false
//            case sfxOnNode:
                //buttonSFX.autoplayLooped = true
            case returnToMenuSceneButtonNode:
                playButtonSound()
                self.view?.presentScene(MenuScene(fileNamed: "MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
        }
    }
    
    func playButtonSound() {
        self.run(SKAction.playSoundFileNamed("button.wav", waitForCompletion: false))  //Plays the sound file
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
    
}
