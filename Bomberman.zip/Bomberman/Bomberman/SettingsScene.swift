//
//  SettingsScene.swift
//  Bomberman
//
//  Created by user125107 on 4/25/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class SettingsScene: SKScene {

    var returnToMenuSceneButtonNode:SKSpriteNode!
    var bgmOffNode: SKSpriteNode!
    var bgmOnNode: SKSpriteNode!
    var sfxOffNode: SKSpriteNode!
    var sfxOnNode: SKSpriteNode!

    
    override func didMove(to view: SKView) {
        returnToMenuSceneButtonNode = self.childNode(withName: "returnToMenuSceneButton") as! SKSpriteNode
        bgmOffNode = self.childNode(withName: "bgmOff") as! SKSpriteNode
        bgmOnNode = self.childNode(withName: "bgmOn") as! SKSpriteNode
        sfxOffNode = self.childNode(withName: "sfxOff") as! SKSpriteNode
        sfxOnNode = self.childNode(withName: "sfxOn") as! SKSpriteNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If returnToMenuSceneButton is pressed, game transitions to MenuScene
        
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
            case bgmOffNode:
                bgmOffNode.setScale(1.3)
                bgmOnNode.setScale(1.0)
                music.autoplayLooped = false
            case bgmOnNode:
                bgmOnNode.setScale(1.3)
                bgmOffNode.setScale(1.0)
                music.autoplayLooped = true
            case sfxOffNode:
                sfxOffNode.setScale(1.3)
                sfxOnNode.setScale(1.0)
                playSFX = false
            case sfxOnNode:
                sfxOnNode.setScale(1.3)
                sfxOffNode.setScale(1.0)
                playSFX = true
            case returnToMenuSceneButtonNode:
                playButtonSound()
                self.view?.presentScene(MenuScene(fileNamed: "MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
        }
    }
    
    func playButtonSound() {
        if playSFX{
            self.run(SKAction.playSoundFileNamed("button.wav", waitForCompletion: false))  //Plays the sound file
        }
        else{
            playSFX = false
        }
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
    
}
