//
//  PlayerAnimation.swift
//  PillBoy
//
//  Created by student on 5/11/17.
//  Copyright © 2017 CMPE137. All rights reserved.
//

import SpriteKit

class PlayerAnimation {
    
    
    //Walk Down
    let pd0 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_down_0.png")
    let pd1 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_down_1.png")
    let pd2 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_down_2.png")
    let pd3 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_down_3.png")
    
    //Hurt
    let ph0 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_hurt_0.png")
    
    //Walk Left
    let pl0 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_left_0.png")
    let pl1 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_left_1.png")
    let pl2 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_left_2.png")
    let pl3 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_left_3.png")
    
    //Walk Right
    let pr0 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_right_0.png")
    let pr1 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_right_1.png")
    let pr2 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_right_2.png")
    let pr3 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_right_3.png")
    
    //Walk Up
    let pu0 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_up_0.png")
    let pu1 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_up_1.png")
    let pu2 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_up_2.png")
    let pu3 = SKTextureAtlas(named: "texture").textureNamed("spr_p1_up_3.png")
    

    var walkDownFrames: [SKTexture]! {
        get {
            return [pd0, pd1, pd2, pd3]
        }
    }
    var walkLeftFrames: [SKTexture] {
        get {
            return [pl0, pl1, pl2, pl3]
        }
    }
    var walkRightFrames: [SKTexture] {
        get {
            return [pr0, pr1, pr2, pr3]
        }
    }
    var walkUpFrames: [SKTexture] {
        get {
            return [pu0, pu1, pu2, pu3]
        }
    }
    var hurtFrames: [SKTexture] {
        get {
            return [ph0]
        }
    }

    init() {
        //Define animations

    }
    
    
}
