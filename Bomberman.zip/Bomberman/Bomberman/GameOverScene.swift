//
//  GameOverScene.swift
//  Bomberman
//
//  Created by user125107 on 4/1/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class GameOverScene: SKScene {
    
    var returnToMenuSceneButtonNode:SKSpriteNode!
    var addToLeaderboardButtonNode:SKSpriteNode!
    var viewLeaderboardButtonNode:SKSpriteNode!
    
    override func didMove(to view: SKView) {
        returnToMenuSceneButtonNode = self.childNode(withName: "returnToMenuSceneButton") as! SKSpriteNode
        addToLeaderboardButtonNode = self.childNode(withName: "addToLeaderboardButton") as! SKSpriteNode
        viewLeaderboardButtonNode = self.childNode(withName: "viewLeaderboardButton") as! SKSpriteNode
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If returnToMenuSceneButton is pressed, game transitions to MenuScene
        
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
                
            case addToLeaderboardButtonNode:
                playButtonSound()
                
            case viewLeaderboardButtonNode:
                playButtonSound()
                
            case returnToMenuSceneButtonNode:
                playButtonSound()
                self.view?.presentScene(MenuScene(fileNamed: "MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
        }
    }
    
    func playButtonSound() {
        if playSFX{
            self.run(SKAction.playSoundFileNamed("button.wav", waitForCompletion: false))  //Plays the sound file
        }
        else{
            playSFX = false
        }
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
}

            
