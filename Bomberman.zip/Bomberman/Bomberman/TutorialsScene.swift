//
//  TutorialsScene.swift
//  Bomberman
//
//  Created by user125107 on 4/25/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

class TutorialsScene: SKScene {

    var returnToMenuSceneButtonNode:SKSpriteNode!
    var spriteUpNode:SKSpriteNode!
    var spriteDownNode:SKSpriteNode!
    var spriteLeftNode:SKSpriteNode!
    var spriteRightNode:SKSpriteNode!
    var controlUpNode:SKLabelNode!
    var controlDownNode:SKLabelNode!
    var controlLeftNode:SKLabelNode!
    var controlRightNode:SKLabelNode!
    var titleLabelNode: SKLabelNode!
    
    override func didMove(to view: SKView) {
        returnToMenuSceneButtonNode = self.childNode(withName: "returnToMenuSceneButton") as! SKSpriteNode
        spriteUpNode = self.childNode(withName: "spriteUp") as! SKSpriteNode
        spriteDownNode = self.childNode(withName: "spriteDown") as! SKSpriteNode
        spriteLeftNode = self.childNode(withName: "spriteLeft") as! SKSpriteNode
        spriteRightNode = self.childNode(withName: "spriteRight") as! SKSpriteNode
        controlUpNode = self.childNode(withName: "controlUp") as! SKLabelNode
        controlDownNode = self.childNode(withName: "controlDown") as! SKLabelNode
        controlLeftNode = self.childNode(withName: "controlLeft") as! SKLabelNode
        controlRightNode = self.childNode(withName: "controlRight") as! SKLabelNode
        titleLabelNode = self.childNode(withName: "titleLabel") as! SKLabelNode
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If returnToMenuSceneButton is pressed, game transitions to MenuScene
        if let touch = touches.first {
        
            let node = atPoint(touch.location(in: self))
        
            switch node {
            case returnToMenuSceneButtonNode:
                self.view?.presentScene(MenuScene(fileNamed: "MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
            
        }
        
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
    
}
