//
//  WelcomeScene.swift
//  Bomberman
//
//  Created by Student on 5/15/17.
//  Copyright © 2017 user125107. All rights reserved.
//

import UIKit
import SpriteKit

let music = SKAudioNode(fileNamed: "Latin_Industries.mp3")
var playSFX = true

class WelcomeScene: SKScene {
    
    var startGameButtonNode:SKSpriteNode!
    
    override func didMove(to view: SKView) {
        startGameButtonNode = self.childNode(withName: "startGameButton") as! SKSpriteNode
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { //If startGameButton is pressed, game transitions to MenuScene
        
        if let touch = touches.first {
            let node = atPoint(touch.location(in: self))
            
            switch node {
            case startGameButtonNode:
                playButtonSound()
                self.view?.presentScene(MenuScene(fileNamed: "MenuScene")!, transition: SKTransition.fade(withDuration: 1))
            default:
                break;
            }
        }
    }
    
    func playButtonSound() {
        if playSFX{
            self.run(SKAction.playSoundFileNamed("button.wav", waitForCompletion: false))  //Plays the sound file
        }
        else{
            playSFX = false
        }
    }
    
    override func update(_ currentTime: TimeInterval){
        //Called before each frame is rendered
    }
}
